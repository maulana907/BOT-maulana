<h1 align="center">WELCOME BACK TO <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="60px" alt="hi"><br>ZEXY MZH!!!</h1>








- 🌱 I’m currently learning **nothing**.

- 👀 I'm currently focusing on **JavaScript**.



- 👥 Subscribe channel kami [`YOUTUBE`](https://youtube.com/channel/UC0adT-_E44gWb9DhnWWPC8g
<img src="https://raw.githubusercontent.com/TheDudeThatCode/TheDudeThatCode/master/Assets/Mario_Gameplay.gif"/>


## CARA INSTALL
siapkan 2 Hp untuk scanning nanti 
<p align="center">
  
install apk [`TERMUX`](https://play.google.com/store/apps/details?id=com.termux)
## COMMAND
ikuti command berikut

$ pkg update && pkg upgrade

$ apt-get update

$ apt-get upgrade

$ pkg install git

$ pkg install nodejs

$ pkg install wget

$ pkg install ffmpeg

$ pkg install npm 

$ git clone https://github.com/zexymzh708/zxbotv1

$ cd zxbot1

$ bash install.sh

Yang terakhir

$ node index.js

## Rules

CTRL+z untuk matiin bot

dan kalo mengaktifkan

Ketik 

$ cd zxbotv1

$ node index.js





 







</p>







</p>
