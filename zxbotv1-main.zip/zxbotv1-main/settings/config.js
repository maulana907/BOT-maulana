const config = {
        botName: 'ZexyBOT',
        ownerName: 'Zexy',
        youtube: 'YOUTUBE_LINK',
        instagram: 'INSTAGRAM_LINK',
}
