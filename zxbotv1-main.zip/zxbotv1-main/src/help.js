const help = (prefix) => {
	return `
「 *ZEXYBOT* 」

◪ *info OWNER*
  ❏ Prefix: 「  ${prefix}  」
  ❏ Creator : ZEXY MZH
  ❏ YOUTUBE: https://youtube.com/channel/UC0adT-_E44gWb9DhnWWPC8g
          *RULES*
SEBELUM GUNAKAN BOT ANDA HARUS DAFTAR DULU,DAN JANGAN SPAM

◪ *TENTANG BOT*
  │
  ├─ ❏ ${prefix}info
  ├─ ❏ ${prefix}owner
  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}chatlist
  ├─ ❏ ${prefix}ping
  └─ ❏ ${prefix}bug
◪ *FAZER*
  │
  ├─ ❏ ${prefix}sticker
  ├─ ❏ ${prefix}stickergif
  ├─ ❏ ${prefix}shota
  ├─ ❏ ${prefix}bpink
  ├─ ❏ ${prefix}marvellogo
  ├─ ❏ ${prefix}snowwrite
  ├─ ❏ ${prefix}3dtext
  ├─ ❏ ${prefix}ninjalogo
  ├─ ❏ ${prefix}water
  ├─ ❏ ${prefix}firetext
  ├─ ❏ ${prefix}logowolf
  ├─ ❏ ${prefix}logowolf2
  ├─ ❏ ${prefix}phlogo
  ├─ ❏ ${prefix}glitch
  ├─ ❏ ${prefix}neonlogo
  ├─ ❏ ${prefix}neonlogo2
  ├─ ❏ ${prefix}lionlogo
  ├─ ❏ ${prefix}jokerlogo
  ├─ ❏ ${prefix}shadow
  ├─ ❏ ${prefix}burnpaper
  ├─ ❏ ${prefix}coffee
  ├─ ❏ ${prefix}lovepaper
  ├─ ❏ ${prefix}woodblock
  ├─ ❏ ${prefix}qowheart
  ├─ ❏ ${prefix}mutgrass
  ├─ ❏ ${prefix}undergocean
  ├─ ❏ ${prefix}woodenboards
  ├─ ❏ ${prefix}wolfmetal
  ├─ ❏ ${prefix}metalictglow
  ├─ ❏ ${prefix}8bit
  ├─ ❏ ${prefix}firetext
  ├─ ❏ ${prefix}3dtext
  ├─ ❏ ${prefix}ttp
  ├─ ❏ ${prefix}herrypotter
  ├─ ❏ ${prefix}pubglogo
  └─ ❏ ${prefix}quotemaker
◪ *MEDIA*
  │
  ├─ ❏ ${prefix}trendtwit
  ├─ ❏ ${prefix}randomkpop
  └─ ❏ ${prefix}ytsearch
◪ *EDUCATION*
  │
  ├─ ❏ ${prefix}wiki
  ├─ ❏ ${prefix}wikien
  ├─ ❏ ${prefix}nulis
  ├─ ❏ ${prefix}quotes
  ├─ ❏ ${prefix}quotes2
  └─ ❏ ${prefix}artinama
◪ *KERANG AJAIB*
  │
  ├─ ❏ ${prefix}apakah
  ├─ ❏ ${prefix}kapankah
  ├─ ❏ ${prefix}rate
  ├─ ❏ ${prefix}game
  └─ ❏ ${prefix}bisakah
◪ *DOWNLOADER*
  │
  ├─ ❏ ${prefix}images
  ├─ ❏ ${prefix}ytmp3
  ├─ ❏ ${prefix}ytmp4
  ├─ ❏ ${prefix}tiktok
  └─ ❏ ${prefix}joox
◪ *CONVERTER*
  │
  ├─ ❏ ${prefix}toimg
  └─ ❏ ${prefix}tomp3
◪ *MEME*
  │
  ├─ ❏ ${prefix}meme
  └─ ❏ ${prefix}memeindo
◪ *AUDIO*
  │
  ├─ ❏ ${prefix}play
  └─ ❏ ${prefix}tts
◪ *MÚSIC*
  │
  ├─ ❏ ${prefix}lirik
  └─ ❏ ${prefix}chord
◪ *ISLAM*
  │
  └─ ❏ ${prefix}quran
◪ *STALK*
  │
  ├─ ❏ ${prefix}tiktokstalk
  ├─ ❏ ${prefix}trendtwit
  └─ ❏ ${prefix}igstalk
◪ *WIBU*
  │
  ├─ ❏ ${prefix}neonime
  ├─ ❏ ${prefix}pokemon
  ├─ ❏ ${prefix}loli
  ├─ ❏ ${prefix}waifu
  ├─ ❏ ${prefix}randomanime
  ├─ ❏ ${prefix}husbu
  ├─ ❏ ${prefix}husbu2
  ├─ ❏ ${prefix}animecry
  ├─ ❏ ${prefix}wait
  ├─ ❏ ${prefix}neko
  └─ ❏ ${prefix}nekonime
◪ *18++*
  │
  ├─ ❏ ${prefix}randomhentai
  ├─ ❏ ${prefix}nsfwtrap
  ├─ ❏ ${prefix}nsfwloli
  ├─ ❏ ${prefix}nsfwbobs
  ├─ ❏ ${prefix}nsfwass
  ├─ ❏ ${prefix}nsfwlowjob
  └─ ❏ ${prefix}nsfwneko
◪ *SOSIAL*
  │
  ├─ ❏ ${prefix}alay
  ├─ ❏ ${prefix}gantengcek
  ├─ ❏ ${prefix}cantikcek
  ├─ ❏ ${prefix}watak
  ├─ ❏ ${prefix}hobby
  ├─ ❏ ${prefix}game
  ├─ ❏ ${prefix}bucin
  ├─ ❏ ${prefix}trust
  ├─ ❏ ${prefix}dare
  ├─ ❏ ${prefix}map
  ├─ ❏ ${prefix}hilih
  └─ ❏ ${prefix}simi
◪ *INFORMASI*
  │
  ├─ ❏ ${prefix}bahasa
  ├─ ❏ ${prefix}kodenegara
  ├─ ❏ ${prefix}kbbi
  ├─ ❏ ${prefix}wiki
  ├─ ❏ ${prefix}wikien
  ├─ ❏ ${prefix}fakta
  ├─ ❏ ${prefix}infocuaca
  ├─ ❏ ${prefix}infogempa
  ├─ ❏ ${prefix}jadwaltvnow
  └─ ❏ ${prefix}covid
◪ *ADMIN GROUP*
  │
  ├─ ❏ ${prefix}add
  ├─ ❏ ${prefix}kick
  ├─ ❏ ${prefix}groupbuka
  ├─ ❏ ${prefix}grouptutup
  ├─ ❏ ${prefix}tagme
  ├─ ❏ ${prefix}tagall
  ├─ ❏ ${prefix}tagall2
  ├─ ❏ ${prefix}tagall3
  ├─ ❏ ${prefix}tagall4
  ├─ ❏ ${prefix}tagall5
  ├─ ❏ ${prefix}linkgc
  ├─ ❏ ${prefix}ownergrup
  ├─ ❏ ${prefix}hidetag
  ├─ ❏ ${prefix}setpp
  ├─ ❏ ${prefix}setname
  ├─ ❏ ${prefix}setdec
  ├─ ❏ ${prefix}listadmin
  ├─ ❏ ${prefix}simih [1/0]
  ├─ ❏ ${prefix}welcome [1/0]
  └─ ❏ ${prefix}msfw [1/0]
◪ *OWNER*
  │
  ├─ ❏ ${prefix}setprefix
  ├─ ❏ ${prefix}block
  ├─ ❏ ${prefix}unblock
  ├─ ❏ ${prefix}setppbot
  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}chatlist
  ├─ ❏ ${prefix}delete
  ├─ ❏ ${prefix}bc
  ├─ ❏ ${prefix}bcgc
  ├─ ❏ ${prefix}clone
  └─ ❏ ${prefix}clearall
◪ *OUTROS*
  │
  ├─ ❏ ${prefix}send
  ├─ ❏ ${prefix}spamcall
  ├─ ❏ ${prefix}wame
  ├─ ❏ ${prefix}virtex
  ├─ ❏ ${prefix}exe
  ├─ ❏ ${prefix}qrcode
  ├─ ❏ ${prefix}afk
  ├─ ❏ ${prefix}timer
  ├─ ❏ ${prefix}testime
  ├─ ❏ ${prefix}semoji
  ├─ ❏ ${prefix}fml
  └─ ❏ ${prefix}fml2
`
}

exports.help = help
